"""Pack operators for UVV addon - UNIV 1:1 Copy"""

import bpy
import bmesh
from bpy.props import BoolProperty, EnumProperty, IntProperty
from ..properties import get_uvv_settings
from .. import utils
from ..types import UMeshes, AdvIslands
from math import sqrt, isclose


class UVV_OT_Pack(bpy.types.Operator):
    """Pack selected islands - UNIV 1:1 Copy"""
    bl_idname = 'uv.uvv_pack'
    bl_label = 'Pack'
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = f"Pack selected islands\n\n" \
        f"Has [P] keymap, but it conflicts with the 'Pin' operator"

    # Use settings from properties - these will show in redo panel
    use_settings: BoolProperty(
        name="Use Settings",
        description="Use settings from properties (overrides individual values below)",
        default=True
    )

    # Native Blender settings
    shape_method: EnumProperty(
        name='Shape Method',
        default='CONCAVE',
        items=[
            ('CONCAVE', 'Exact', 'Uses exact geometry'),
            ('AABB', 'Fast', 'Uses bounding boxes')
        ]
    )

    scale: BoolProperty(name='Scale', default=True)
    rotate: BoolProperty(name='Rotate', default=True)
    normalize_islands: BoolProperty(name='Normalize', default=False)

    rotate_method: EnumProperty(
        name='Rotation Method',
        default='CARDINAL',
        items=[
            ('ANY', 'Any', "Any angle is allowed"),
            ('AXIS_ALIGNED', 'Orient', "Rotated to minimal rectangle"),
            ('CARDINAL', 'Step 90', "Only 90 degree rotations")
        ]
    )

    pin: BoolProperty(name='Lock Pinned Islands', default=False)
    merge_overlap: BoolProperty(name='Lock Overlaps', default=False)

    udim_source: EnumProperty(
        name='Pack to',
        default='CLOSEST_UDIM',
        items=[
            ('CLOSEST_UDIM', 'Closest UDIM', "Pack to closest UDIM"),
            ('ACTIVE_UDIM', 'Active UDIM', "Pack to active UDIM"),
            ('ORIGINAL_AABB', 'Original BBox', "Pack to starting bounding box")
        ]
    )

    padding: IntProperty(name='Padding', default=4, min=0, max=256)

    def invoke(self, context, event):
        # Load current settings into operator properties
        if self.use_settings:
            settings = get_uvv_settings()
            self.shape_method = settings.shape_method
            self.scale = settings.scale
            self.rotate = settings.rotate
            self.normalize_islands = settings.normalize_islands
            self.rotate_method = settings.rotate_method
            self.pin = settings.pin
            self.merge_overlap = settings.merge_overlap
            self.udim_source = settings.udim_source
            self.padding = settings.padding
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        settings = get_uvv_settings()

        # Use settings toggle
        layout.prop(self, 'use_settings')
        layout.separator()

        if not self.use_settings:
            # Show all settings in redo panel (matching Pack Settings layout)
            if not settings.use_uvpm:
                # Native Blender mode
                box = layout.box()
                box.prop(self, 'shape_method', expand=True)

                layout.separator(factor=0.5)

                box = layout.box()
                box_col = box.column(align=True)
                box_col.prop(self, 'scale')
                if self.scale:
                    split = box_col.split(factor=0.1, align=True)
                    split.label(text='')
                    split.prop(self, 'normalize_islands')

                layout.separator(factor=0.5)

                box = layout.box()
                box_col = box.column(align=True)
                box_col.prop(self, 'rotate')
                if self.rotate:
                    split = box_col.split(factor=0.1, align=True)
                    split.label(text='')
                    split.prop(self, 'rotate_method', text='')

                layout.separator(factor=0.5)

                box = layout.box()
                box.label(text="Lock")
                box_col = box.column(align=True)
                row = box_col.row(align=True)
                row.prop(self, 'pin', text='Pinned Islands')
                row.prop(self, 'merge_overlap', text='Overlaps')

                layout.separator(factor=0.5)

                box = layout.box()
                box.label(text="Misc")
                box_col = box.column(align=True)
                row = box_col.row(align=True)
                row.label(text='Padding')
                box_col.prop(self, 'padding', slider=True)
                box_col.separator()
                box_col.label(text='Pack to')
                box_col.prop(self, 'udim_source', text='')

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH' and (obj := context.active_object) and obj.type == 'MESH'

    def execute(self, context):
        settings = get_uvv_settings()

        # Apply operator properties to settings if not using settings
        if not self.use_settings:
            settings.shape_method = self.shape_method
            settings.scale = self.scale
            settings.rotate = self.rotate
            settings.normalize_islands = self.normalize_islands
            settings.rotate_method = self.rotate_method
            settings.pin = self.pin
            settings.merge_overlap = self.merge_overlap
            settings.udim_source = self.udim_source
            settings.padding = self.padding

        # Execute pack operation
        if settings.use_uvpm:
            if hasattr(context.scene, 'uvpm3_props'):
                result = self.pack_uvpm()
            else:
                settings.use_uvpm = False
                self.report({'WARNING'}, 'UVPackmaster not found')
                return {'CANCELLED'}
        else:
            result = self.pack_native()

        # Update UV coverage after packing
        self.update_uv_coverage(context)

        return result

    def update_uv_coverage(self, context):
        """Update UV coverage after packing"""
        try:
            # Use the same calculation method as the Get UV Coverage operator
            coverage_op = UVV_OT_GetUVCoverage()
            coverage = coverage_op.calculate_uv_coverage(context)
            settings = get_uvv_settings()
            settings.uv_coverage = coverage
        except Exception as e:
            # Silently fail - coverage update is not critical
            print(f"UV coverage update failed: {e}")

    @staticmethod
    def pack_uvpm():
        # TODO: Add Info about unselected and hidden faces
        # TODO: Use UniV orient (instead Pre-Rotation) and remove AXIS_ALIGNED method
        # TODO: Use UniV normalize
        # TODO: Add for Exact Overlap Mode threshold
        # TODO: Add scale checker for packed meshes

        settings = get_uvv_settings()
        uvpm_settings = bpy.context.scene.uvpm3_props

        if hasattr(uvpm_settings, 'default_main_props'):
            uvpm_settings = uvpm_settings.default_main_props

        if hasattr(uvpm_settings, 'scale_mode'):
            uvpm_settings.scale_mode = '0' if settings.scale else '1'
        else:
            uvpm_settings.fixed_scale = not settings.scale

        uvpm_settings.pixel_margin_enable = True
        uvpm_settings.pixel_margin_tex_size = min(int(settings.size_x), int(settings.size_y))
        uvpm_settings.pixel_margin = settings.padding

        # Only set heuristic time values if heuristic is enabled
        if uvpm_settings.heuristic_enable:
            total_selected = sum(umesh.total_face_sel for umesh in UMeshes.calc(verify_uv=False))
            if total_selected > 50_000:
                time_in_sec = 8
            elif total_selected > 10_000:
                time_in_sec = 4
            else:
                time_in_sec = 2
            uvpm_settings.heuristic_max_wait_time = time_in_sec
            uvpm_settings.heuristic_search_time = time_in_sec * 4

        if size := utils.get_active_image_size():
            uvpm_settings.tex_ratio = size[0] != size[1]
        else:
            uvpm_settings.tex_ratio = False

        if uvpm_settings.precision == 500:
            uvpm_settings.precision = 800

        return bpy.ops.uvpackmaster3.pack('INVOKE_REGION_WIN', mode_id="pack.single_tile", pack_op_type='0')

    def normalize_texel_density(self):
        """
        Normalize texel density across all selected UV islands.
        This ensures all islands have the same TD before packing.
        Uses UNIV-style AdvIsland system for performance.
        """
        settings = get_uvv_settings()
        target_td = settings.texel_density
        texture_size = (int(settings.texture_size_x) + int(settings.texture_size_y)) / 2.0

        # Use UMeshes to get selected meshes efficiently (UNIV pattern)
        umeshes = UMeshes(report=self.report)
        if not umeshes.is_edit_mode:
            return  # Only works in edit mode

        # Get only selected meshes with UV faces
        selected_umeshes, unselected_umeshes = umeshes.filtered_by_selected_and_visible_uv_faces()
        if not selected_umeshes:
            return  # No selected faces with UVs

        umeshes = selected_umeshes

        # Process each mesh
        for umesh in umeshes:
            umesh.update_tag = False
            scale = umesh.check_uniform_scale(report=self.report)

            # Get islands using UNIV's efficient AdvIslands system
            adv_islands = AdvIslands.calc_extended_with_mark_seam(umesh)
            if not adv_islands:
                continue

            # Normalize each island to target TD
            for isl in adv_islands:
                # Calculate areas for this island
                isl.calc_area_uv()
                isl.calc_area_3d(scale=scale)

                # Use UNIV's set_texel method (fast!)
                status = isl.set_texel(target_td, texture_size)
                if status is not None:
                    umesh.update_tag |= status

        # Update all modified meshes
        umeshes.update(info='Islands normalized for packing')

    def pack_native(self):
        settings = get_uvv_settings()

        # Normalize islands BEFORE packing (if enabled and scale is enabled)
        if settings.normalize_islands and settings.scale:
            self.normalize_texel_density()

        umeshes = UMeshes.calc(verify_uv=False)
        umeshes.fix_context()
        args = {
            'udim_source': settings.udim_source,
            'rotate': settings.rotate,
            'margin': settings.padding / 2 / min(int(settings.size_x), int(settings.size_y))}
        if bpy.app.version >= (3, 5, 0):
            args['margin_method'] = 'FRACTION'
        is_360v = bpy.app.version >= (3, 6, 0)
        if is_360v:
            args['scale'] = settings.scale
            args['rotate_method'] = settings.rotate_method
            args['pin'] = settings.pin
            args['merge_overlap'] = settings.merge_overlap
            args['pin_method'] = settings.pin_method
            args['shape_method'] = settings.shape_method

        import platform
        if is_360v and settings.shape_method != 'AABB' and platform.system() == 'Windows':
            import threading
            threading.Thread(target=self.press_enter_key).start()
            return bpy.ops.uv.pack_islands('INVOKE_DEFAULT', **args)  # noqa
        else:
            return bpy.ops.uv.pack_islands('EXEC_DEFAULT', **args)  # noqa

    @staticmethod
    def press_enter_key():
        import ctypes
        VK_RETURN = 0x0D  # Enter  # noqa
        KEYDOWN = 0x0000  # Press  # noqa
        KEYUP = 0x0002  # Release  # noqa
        ctypes.windll.user32.keybd_event(VK_RETURN, 0, KEYDOWN, 0)
        ctypes.windll.user32.keybd_event(VK_RETURN, 0, KEYUP, 0)


class UVV_OT_GetUVCoverage(bpy.types.Operator):
    """Calculate UV coverage percentage"""
    bl_idname = "uv.uvv_get_uv_coverage"
    bl_label = "Get UV Coverage"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return (context.mode == 'EDIT_MESH' and
                context.active_object is not None and
                context.active_object.type == 'MESH')

    def execute(self, context):
        settings = get_uvv_settings()

        try:
            coverage = self.calculate_uv_coverage(context)
            settings.uv_coverage = coverage

            empty_space = max(0.0, 100.0 - coverage)
            self.report({'INFO'}, f"UV Coverage: {coverage:.2f}%, Empty Space: {empty_space:.2f}%")

        except Exception as e:
            self.report({'ERROR'}, f"Coverage calculation failed: {str(e)}")
            settings.uv_coverage = 0.0
            return {'CANCELLED'}

        return {'FINISHED'}

    def calculate_uv_coverage(self, context):
        """Calculate UV coverage for all faces"""
        total_coverage = 0.0

        # Get all selected mesh objects
        mesh_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not mesh_objects:
            mesh_objects = [context.active_object] if context.active_object and context.active_object.type == 'MESH' else []

        if not mesh_objects:
            return 0.0

        for obj in mesh_objects:
            # Get bmesh
            if obj.mode == 'EDIT':
                bm = bmesh.from_edit_mesh(obj.data)
            else:
                bm = bmesh.new()
                bm.from_mesh(obj.data)

            # Get UV layer
            if not bm.loops.layers.uv:
                if obj.mode != 'EDIT':
                    bm.free()
                continue

            uv_layer = bm.loops.layers.uv.active

            # Calculate coverage for all faces
            coverage = self.calculate_face_coverage(bm.faces, uv_layer)
            total_coverage += coverage

            # Clean up if we created a new bmesh
            if obj.mode != 'EDIT':
                bm.free()

        # Coverage is already a percentage from calculate_face_coverage
        return min(total_coverage, 100.0)

    def calculate_face_coverage(self, faces, uv_layer):
        """Calculate the UV area coverage for a set of faces"""
        total_uv_area = 0.0

        for face in faces:
            if face.hide:
                continue

            # Get UV coordinates for this face
            uv_coords = [loop[uv_layer].uv for loop in face.loops]

            if len(uv_coords) < 3:
                continue

            # Calculate area using triangulation
            # For each triangle in the face (using fan triangulation from first vertex)
            face_area = 0.0
            for i in range(1, len(uv_coords) - 1):
                v0 = uv_coords[0]
                v1 = uv_coords[i]
                v2 = uv_coords[i + 1]

                # Triangle area = 0.5 * |cross product|
                # For 2D: area = 0.5 * |x1(y2-y3) + x2(y3-y1) + x3(y1-y2)|
                area = abs(
                    v0.x * (v1.y - v2.y) +
                    v1.x * (v2.y - v0.y) +
                    v2.x * (v0.y - v1.y)
                ) * 0.5

                face_area += area

            total_uv_area += face_area

        # Convert to percentage (UV space is 0-1, so area of 1.0 = 100%)
        coverage_percent = total_uv_area * 100.0

        return coverage_percent


classes = [
    UVV_OT_Pack,
    UVV_OT_GetUVCoverage,
]


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)