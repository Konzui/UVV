# Gizmos module - currently no gizmos registered
# Box mapping gizmo removed - using simpler modifier-based approach


def register():
    pass


def unregister():
    pass
