# Math utilities module - imports from umath_numpy
# This module exists to maintain compatibility with island.py imports

from .umath_numpy import *
